﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Exam_Project_Backend.Migrations
{
    /// <inheritdoc />
    public partial class Initial2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_enrollments_Courses_CourseId",
                table: "enrollments");

            migrationBuilder.DropForeignKey(
                name: "FK_enrollments_Students_StudentId",
                table: "enrollments");

            migrationBuilder.DropIndex(
                name: "IX_enrollments_CourseId",
                table: "enrollments");

            migrationBuilder.DropIndex(
                name: "IX_enrollments_StudentId",
                table: "enrollments");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "IX_enrollments_CourseId",
                table: "enrollments",
                column: "CourseId");

            migrationBuilder.CreateIndex(
                name: "IX_enrollments_StudentId",
                table: "enrollments",
                column: "StudentId");

            migrationBuilder.AddForeignKey(
                name: "FK_enrollments_Courses_CourseId",
                table: "enrollments",
                column: "CourseId",
                principalTable: "Courses",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_enrollments_Students_StudentId",
                table: "enrollments",
                column: "StudentId",
                principalTable: "Students",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
