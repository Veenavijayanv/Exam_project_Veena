﻿using Exam_Project_Backend.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Data;

namespace Exam_Project_Backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EnrollmentController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public EnrollmentController(IConfiguration configuration)
        {

            _configuration = configuration;

        }

        [HttpGet]
        [Route("GetEnrollmentData")]

        public List<Enrollment> GetEnrollmentData()

        {
            SqlConnection conn = new SqlConnection(_configuration.GetConnectionString("default_connection").ToString());


            SqlDataAdapter da = new SqlDataAdapter("sp_getEnrollment_dtls", conn);

            DataTable dt = new DataTable();
            da.Fill(dt);

            List<Enrollment> list = new List<Enrollment>();
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    Enrollment enroll = new Enrollment();
                    enroll.Id = Convert.ToInt32(dt.Rows[i]["Id"].ToString());
                    enroll.StudentId = Convert.ToInt32(dt.Rows[i]["StudentId"].ToString());
                    enroll.CourseId = Convert.ToInt32(dt.Rows[i]["CourseId"].ToString());
                    enroll.EnrollmentDate = Convert.ToDateTime(dt.Rows[i]["EnrollmentDate"]);


                    list.Add(enroll);


                }
            }
            if (list.Count > 0)
            {
                return list;
            }
            else
            {
                return null;
            }

        }

        [HttpPost]
        [Route("AddEnrollment")]

        public string AddEnrollment(Enrollment enrollment)
        {
            SqlConnection conn = new SqlConnection(_configuration.GetConnectionString("default_connection").ToString());
            string msg;
            SqlCommand cmd = new SqlCommand("sp_AddEnrollment", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@StudentId", enrollment.StudentId);

            cmd.Parameters.AddWithValue("@CourseId", enrollment.CourseId);
            cmd.Parameters.AddWithValue("@EnrollmentDate", enrollment.EnrollmentDate);


            conn.Open();
            int i = cmd.ExecuteNonQuery();
            conn.Close();

            if (i > 0)
            {
                msg = "111";//Enrollment Added
            }
            else
            {
                msg = "Error.";
            }
            return msg;
        }
    }
}
