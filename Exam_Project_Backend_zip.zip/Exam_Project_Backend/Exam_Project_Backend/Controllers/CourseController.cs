﻿using Exam_Project_Backend.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Data;

namespace Exam_Project_Backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    
    public class CourseController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public CourseController(IConfiguration configuration)
        {

            _configuration = configuration;

        }

        [HttpGet]
        [Route("GetCourseDetails")]

        public List<Course> GetCourseDetails()

        {
            SqlConnection conn = new SqlConnection(_configuration.GetConnectionString("default_connection").ToString());


            SqlDataAdapter da = new SqlDataAdapter("sp_getcourse_dtls", conn);

            DataTable dt = new DataTable();
            da.Fill(dt);

            List<Course> list = new List<Course>();
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    Course course = new Course();
                    course.Id = Convert.ToInt32(dt.Rows[i]["Id"].ToString());
                    course.Title = dt.Rows[i]["Title"].ToString();
                    course.Description = dt.Rows[i]["Description"].ToString();

                    list.Add(course);


                }
            }
            if (list.Count > 0)
            {
                return list;
            }
            else
            {
                return null;
            }

        }

        [HttpPost]
        [Route("AddCourse")]

        public string AddCourse(Course course)
        {
            SqlConnection conn = new SqlConnection(_configuration.GetConnectionString("default_connection").ToString());
            string msg;
            SqlCommand cmd = new SqlCommand("sp_AddCourse", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Title", course.Title);

            cmd.Parameters.AddWithValue("@Description", course.Description);


            conn.Open();
            int i = cmd.ExecuteNonQuery();
            conn.Close();

            if (i > 0)
            {
                msg = "111";//course Added
            }
            else
            {
                msg = "Error.";
            }
            return msg;
        }
    }
}
