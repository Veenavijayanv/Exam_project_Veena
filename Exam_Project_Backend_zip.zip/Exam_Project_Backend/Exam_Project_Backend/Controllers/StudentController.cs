﻿using Exam_Project_Backend.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Data;

namespace Exam_Project_Backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public StudentController(IConfiguration configuration)
        {
            _configuration = configuration;

        }

        [HttpGet]
        [Route("GetStudentDetails")]

        public List<Student> GetStudentDetails()

        {
            SqlConnection conn = new SqlConnection(_configuration.GetConnectionString("default_connection").ToString());


            SqlDataAdapter da = new SqlDataAdapter("sp_getStudent_dtls", conn);

            DataTable dt = new DataTable();
            da.Fill(dt);

            List<Student> list = new List<Student>();
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    Student student = new Student();
                    student.Id = Convert.ToInt32(dt.Rows[i]["ID"].ToString());
                    student.Name = dt.Rows[i]["Name"].ToString();
                    student.Email = dt.Rows[i]["Email"].ToString();

                    list.Add(student);


                }
            }
            if (list.Count > 0)
            {
                return list;
            }
            else
            {
                return null;
            }

        }

        [HttpPost]
        [Route("AddStudent")]

        public string AddStudent(Student student)
        {
            SqlConnection conn = new SqlConnection(_configuration.GetConnectionString("default_connection").ToString());
            string msg;
            SqlCommand cmd = new SqlCommand("sp_AddStudent", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Name", student.Name);
           
            cmd.Parameters.AddWithValue("@Email", student.Email);
       

            conn.Open();
            int i = cmd.ExecuteNonQuery();
            conn.Close();

            if (i > 0)
            {
                msg = "111";//Student Added
            }
            else
            {
                msg = "Error.";
            }
            return msg;
        }
    }
}
