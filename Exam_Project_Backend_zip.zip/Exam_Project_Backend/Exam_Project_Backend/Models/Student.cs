﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace Exam_Project_Backend.Models
{
    public class Student
    {
        
            [Key]
            public int Id { get; set; }

            [Required]
            public string Name { get; set; }

            [Required]
            [EmailAddress]
            public string Email { get; set; }

            //public ICollection<Enrollment> Enrollments { get; set; }
        


    }
}
