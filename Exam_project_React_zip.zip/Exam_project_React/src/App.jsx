import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import { BrowserRouter,Routes,Route } from 'react-router-dom'
import Nav from '../src/Navbar/Nav'
import Student from './Student/Student'
import Course from './Courses/Course'
import Enrollment from './Enrollments/Enrollment'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <BrowserRouter>
      {/* <Nav/> */}
      <Routes>
      <Route path="/" element={<Enrollment/>}>
        {/* <Route path="/" element={<Student/>}> */}
        <Route path="/Course" element={<Course/>}></Route>
        <Route path="/Enroll" element={<Enrollment/>}></Route>

        </Route>
      </Routes>
      </BrowserRouter>
       
    </>
  )
}

export default App
