import React,{useState,useEffect} from 'react'
import { styled } from '@mui/material/styles';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Modal from '@mui/material/Modal';
import Checkbox from '@mui/material/Checkbox';
import TextField from '@mui/material/TextField';
import FormGroup from '@mui/material/FormGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import axios from 'axios';

const Student = () => {

    const [name,setName]=useState('');
    const [email,setEmail]=useState('');
    const clear=()=>{
        setName('');
        setEmail('');
       
      }

    const StyledTableCell = styled(TableCell)(({ theme }) => ({
        [`&.${tableCellClasses.head}`]: {
          backgroundColor: theme.palette.common.black,
          color: theme.palette.common.white,
        },
        [`&.${tableCellClasses.body}`]: {
          fontSize: 14,
        },
      }));
      
      const StyledTableRow = styled(TableRow)(({ theme }) => ({
        '&:nth-of-type(odd)': {
          backgroundColor: theme.palette.action.hover,
        },
        // hide last border
        '&:last-child td, &:last-child th': {
          border: 0,
        },
      }));

      //Add student

      const handleAdd=()=>{
        debugger;
        const data = {
            name: name,
            email: email,
           
          
          };

         

          const url = 'https://localhost:7213/api/Student/AddStudent'
    axios.post(url, data).then((result) => {
      debugger;
      if (result.data == '111') {
        debugger;
        alert("Student added successfully");
        getData();
        clear();

      }

    }).catch((ex) => {

      alert(ex.message);
      
    })
        
    }


      //Add student end

    const [data,setData]= useState([]);

    useEffect(()=>{
        getData();
    },[])

    const getData = () => {
        debugger;
        axios.get('https://localhost:7213/api/Student/GetStudentDetails')
          .then((result) => {
            debugger;
            setData(result.data)
            
          })
          .catch((error) => {
            console.log(error)
          })
      }
  return (
    <div>
<TableContainer component={Paper}>
              <TableRow>
             <TableCell>
              <TextField id="outlined-basic" label="ENTER NAME" variant="outlined" value={name} onChange={(e)=>setName(e.target.value)}/>
              </TableCell>
              <TableCell>
              <TextField id="outlined-basic" label="ENTER eMAIL" variant="outlined" value={email} onChange={(e)=>setEmail(e.target.value)}/>
              </TableCell> 
              <TableCell>
                <Button variant="contained" color="success" onClick={()=>handleAdd()}>ADD</Button>
                </TableCell>
              </TableRow>
          </TableContainer>

        <TableContainer component={Paper}>
      <Table sx={{ minWidth: 700 }} aria-label="customized table">
        <TableHead>
          <TableRow>
            <StyledTableCell>#</StyledTableCell>
        
            <StyledTableCell align="right">ID</StyledTableCell>
            <StyledTableCell align="right">NAME</StyledTableCell>
            <StyledTableCell align="right">EMAIL</StyledTableCell>
            
          </TableRow>
        </TableHead>
        <TableBody>
          {
          data && data.length>0 ?
          data.map((item,index)=>{
            return(
                <StyledTableRow key={index}>
              <StyledTableCell component="th" scope="row">
                {index+1}
              </StyledTableCell>
              <StyledTableCell align="right">{item.id}</StyledTableCell>
              <StyledTableCell align="right">{item.name}</StyledTableCell>
              <StyledTableCell align="right">{item.email}</StyledTableCell>
              {/* <StyledTableCell align="right">{item.isactive}</StyledTableCell>
              <Stack direction="row" spacing={2}>
                   <Button variant="contained" color="success" onClick={()=>handleEdit(item.id)}>EDIT</Button>
                   <Button variant="outlined" color="error" onClick={()=>handleDelete(item.id)}>DELETE</Button>
              </Stack> */}
            </StyledTableRow>
            )
          })
          :
          'Loading..'
          }

        </TableBody>
      </Table>
    </TableContainer>

    </div>
  )
}

export default Student