import React,{useState,useEffect} from 'react'
import { styled } from '@mui/material/styles';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Modal from '@mui/material/Modal';
import Checkbox from '@mui/material/Checkbox';
import TextField from '@mui/material/TextField';
import FormGroup from '@mui/material/FormGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import axios from 'axios';

const Enrollment = () => {

    const StyledTableCell = styled(TableCell)(({ theme }) => ({
        [`&.${tableCellClasses.head}`]: {
          backgroundColor: theme.palette.common.black,
          color: theme.palette.common.white,
        },
        [`&.${tableCellClasses.body}`]: {
          fontSize: 14,
        },
      }));
      
      const StyledTableRow = styled(TableRow)(({ theme }) => ({
        '&:nth-of-type(odd)': {
          backgroundColor: theme.palette.action.hover,
        },
        // hide last border
        '&:last-child td, &:last-child th': {
          border: 0,
        },
      }));


      const [data,setData]= useState([]);

    useEffect(()=>{
        getData();
    },[])

    const getData = () => {
        debugger;
        axios.get('https://localhost:7213/api/Enrollment/GetEnrollmentData')
          .then((result) => {
            debugger;
            setData(result.data)
            
          })
          .catch((error) => {
            console.log(error)
          })
      }
  return (
    <div>
        <TableContainer component={Paper}>
      <Table sx={{ minWidth: 700 }} aria-label="customized table">
        <TableHead>
          <TableRow>
            <StyledTableCell>#</StyledTableCell>
        
            <StyledTableCell align="right">Student ID</StyledTableCell>
            <StyledTableCell align="right">Course ID</StyledTableCell>
            <StyledTableCell align="right">Enrollment Date</StyledTableCell>
            
          </TableRow>
        </TableHead>
        <TableBody>
          {
          data && data.length>0 ?
          data.map((item,index)=>{
            return(
                <StyledTableRow key={index}>
              <StyledTableCell component="th" scope="row">
                {index+1}
              </StyledTableCell>
              <StyledTableCell align="right">{item.studentId}</StyledTableCell>
              <StyledTableCell align="right">{item.courseId}</StyledTableCell>
              <StyledTableCell align="right">{item.enrollmentDate}</StyledTableCell>
              
            </StyledTableRow>
            )
          })
          :
          'Loading..'
          }

        </TableBody>
      </Table>
    </TableContainer>
    </div>
  )
}

export default Enrollment